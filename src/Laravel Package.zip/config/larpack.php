<?php

return [
    'admin_prefix' => 'admin'
];