@extends('full-Admin-Panel.layout.backend')
@section('content')
<div class="container ">
    <div class="row">
        {{-- <div class="col-12 mt-5">
            <div class="title" style="text-align: center">
                <h1 class="wow fadeInUp" data-wow-delay=".3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp; color: black;">
                    Dashboard
                </h1>
            </div>
        </div> --}}
        <div class="col-12 mt-5">
            <br>
            <br>
            <br>
            <br>
            <br>
            <div class="title" style="text-align: center">
                <h1> Welcome </h1>
                {{-- <h1>Welcome To Ma Tech Solution Bpo Dashboard</h1> --}}
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
        </div>
    </div>
</div>
@endsection
